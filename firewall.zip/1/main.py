#!/usr/bin/env python3
import asyncio
from flask import Flask,render_template,request
import subprocess
app = Flask(__name__, template_folder='templates')

key1 = ""
key2 = ""
host_send = ""
host_receive = ""
mode = 'normal'

@app.route('/index')
def hello_world():
    return render_template('Untitled-1.html')

@app.route('/hello', methods=['POST'])
def hello():
    form = request.form
    host_send = form.get('cm1')
    host_receive = form.get('cm2')
    return key1, key2

# async def get_host():
#     host_send = key1
#     host_receive = key2
#     mode = 'normal'
#     return host_send, host_receive, mode

def main():
    # renwu = [get_host()]
    # loops = asyncio.get_event_loop()
    # loops.run_until_complete(asyncio.wait(renwu))
    # output = 'OK'
    app.run()

if __name__ == "__main__":
    main()
