#!/usr/bin/env python3
import argparse
import os
import sys
import json
from time import sleep
import json
import grpc

# Import P4Runtime lib from parent utils dir
# Probably there's a better way of doing this.
sys.path.append(
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 '../../utils/'))

import p4runtime_lib.bmv2
import p4runtime_lib.helper
from p4runtime_lib.switch import ShutdownAllSwitchConnections


def load_json(sid, p4info_helper, bmv2_file_path, json_path):
    switch = p4runtime_lib.bmv2.Bmv2SwitchConnection(
        name='s' + str(sid + 1),
        address='127.0.0.1:5005' + str(sid + 1),
        device_id=sid
    )
    switch.MasterArbitrationUpdate()
    switch.SetForwardingPipelineConfig(p4info=p4info_helper.p4info, bmv2_json_file_path=bmv2_file_path)

    with open(json_path, 'r') as f:
        switch_info = json.load(f)
        table_entries = switch_info['table_entries']

        for table_entry_info in table_entries:
            if table_entry_info.get('match'):
                switch.WriteTableEntry(p4info_helper.buildTableEntry(
                    table_name=table_entry_info['table'],
                    match_fields=table_entry_info['match'],
                    action_name=table_entry_info['action_name'],
                    action_params=table_entry_info['action_params']))
            else:
                switch.WriteTableEntry(p4info_helper.buildTableEntry(
                    table_name=table_entry_info['table'],
                    action_name=table_entry_info['action_name'],
                    action_params=table_entry_info['action_params']))

    return switch


def writeCheckPortRules(p4info_helper, sw: p4runtime_lib.bmv2.Bmv2SwitchConnection, ingress_port, egress_spec,
                        dir=0):
    table_entry = p4info_helper.buildTableEntry(
        table_name="MyIngress.check_ports",
        match_fields={
            "standard_metadata.ingress_port": ingress_port,
            "standard_metadata.egress_spec": egress_spec
        },
        action_name="MyIngress.set_direction",
        action_params={
            "dir": dir
        })
    sw.WriteTableEntry(table_entry)


def printGrpcError(e):
    print("gRPC Error:", e.details(), end=' ')
    status_code = e.code()
    print("(%s)" % status_code.name, end=' ')
    traceback = sys.exc_info()[2]
    print("[%s:%d]" % (traceback.tb_frame.f_code.co_filename, traceback.tb_lineno))


def writeFireWallRule(p4info_helper, sw):
    writeCheckPortRules(p4info_helper, sw, 1, 3, 0)
    writeCheckPortRules(p4info_helper, sw, 1, 4, 0)
    writeCheckPortRules(p4info_helper, sw, 2, 3, 0)
    writeCheckPortRules(p4info_helper, sw, 2, 4, 0)

    writeCheckPortRules(p4info_helper, sw, 3, 1, 1)
    writeCheckPortRules(p4info_helper, sw, 3, 2, 1)
    writeCheckPortRules(p4info_helper, sw, 4, 1, 1)
    writeCheckPortRules(p4info_helper, sw, 4, 2, 1)


def main(p4info_file_path, bmv2_file_path):
    # Instantiate a P4Runtime helper from the p4info file
    p4info_helper = p4runtime_lib.helper.P4InfoHelper(p4info_file_path)

    try:
        s1 = load_json(0, p4info_helper, bmv2_file_path, './pod-topo/s1-runtime.json')
        s2 = load_json(1, p4info_helper, bmv2_file_path, './pod-topo/s2-runtime.json')
        s3 = load_json(2, p4info_helper, bmv2_file_path, './pod-topo/s3-runtime.json')
        s4 = load_json(3, p4info_helper, bmv2_file_path, './pod-topo/s4-runtime.json')

        if sys.argv[0] == 's1':
            writeFireWallRule(p4info_helper, s1)
        elif sys.argv[0] == 's2':
            writeFireWallRule(p4info_helper, s2)

    except KeyboardInterrupt:
        print(" Shutting down.")
    except grpc.RpcError as e:
        printGrpcError(e)

    ShutdownAllSwitchConnections()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='P4Runtime Controller')
    parser.add_argument('--firewall', help='firewall',
                        type=str, action="store", required=False, default='default_value')
    parser.add_argument('--p4info', help='p4info proto in text format from p4c',
                        type=str, action="store", required=False,
                        default='./build/firewall.p4.p4info.txt')
    parser.add_argument('--bmv2-json', help='BMv2 JSON file from p4c',
                        type=str, action="store", required=False,
                        default='./build/firewall.json')
    args = parser.parse_args()

    if not os.path.exists(args.p4info):
        parser.print_help()
        print("\np4info file not found: %s\nHave you run 'make'?" % args.p4info)
        parser.exit(1)
    if not os.path.exists(args.bmv2_json):
        parser.print_help()
        print("\nBMv2 JSON file not found: %s\nHave you run 'make'?" % args.bmv2_json)
        parser.exit(1)
    main(args.p4info, args.bmv2_json)
